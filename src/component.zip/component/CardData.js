import React from 'react'
import card1 from './card1.png'

export const CardData = ({menuData}) => {
  return (
   <>
   <div  className='property'>
   <h6> Recomended</h6>
   <h5> Properties near you</h5>
   </div>
   {
    menuData.map((curelement)=>{
     return(
        <>
        <div className="container">
        <div className="card-container1 "  key={curelement.id}>
            <div className="card1">
                <div className="card-body1">
                    <img src={curelement.image} className='card-media1'/>
                    <p>{curelement.price}</p>
                    <p>{curelement.size}</p>
                    <p>{curelement.place}</p>
                    <p>{curelement.name}</p>
                </div>
            </div>
        </div>
        </div>
        </>
     )
    })
   }
    
        
   </>
  )
}


export default CardData;
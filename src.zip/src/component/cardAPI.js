    const Cards = [{
        id:1,
        image:"images/card1.png",
        price:10000,
        size:" 2bedroom 12sq.ft",
        name: "paradise",                                           
        place:"banglore"

    },
    {
        id:2,
        image:"images/card2.png",
        price:10000,
        size:" 2bedroom 12sq.ft",
        name: "paradise",
        place:"banglore"

    },
    {
        id:3,
        image:"images/card3.png",
        price:10000,
        size:" 2bedroom 12sq.ft",
        name: "paradise",
        place:"banglore"

    }]

    export default Cards;
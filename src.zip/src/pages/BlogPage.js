import React from 'react'
import Navbar1 from '../component/Navbar1';

export const BlogPage = () => {
  return (
    <>
    <div>BlogPage</div>
    <Navbar1/>
    </>
  )
}
export default BlogPage;
import logo from './logo.svg';
import './App.css';
import Navbar from './component/navbar';

function App() {
  return (
    <>
      <Navbar/>
    </>
  );
}

export default App;
